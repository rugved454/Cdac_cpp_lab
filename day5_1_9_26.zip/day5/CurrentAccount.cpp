#include "CurrentAccount.h"

CurrentAccount::CurrentAccount(int aid, const char* f, const char* l, const char* mob, const char* em, int p, double bal, int tpd, double aab)
    : Account(aid, f, l, mob, em, p, bal, "Current")
{
    transactionsPerDay = tpd;
    averageAnnualBalance = aab;
}

CurrentAccount::CurrentAccount(const CurrentAccount &ca)
    : Account(ca)
{
    transactionsPerDay = ca.transactionsPerDay;
    averageAnnualBalance = ca.averageAnnualBalance;
}

CurrentAccount::~CurrentAccount()
{
    // Destructor - cleanup handled by base class
}

void CurrentAccount::setTransactionsPerDay(int tpd)
{
    transactionsPerDay = tpd;
}

int CurrentAccount::getTransactionsPerDay() const
{
    return transactionsPerDay;
}

void CurrentAccount::setAverageAnnualBalance(double aab)
{
    averageAnnualBalance = aab;
}

double CurrentAccount::getAverageAnnualBalance() const
{
    return averageAnnualBalance;
}

void CurrentAccount::displayData()
{
    Account::displayData();
    cout << "Transactions Per Day: " << transactionsPerDay << endl;
    cout << "Average Annual Balance: " << averageAnnualBalance << endl;
}

ostream& operator<<(ostream& out, const CurrentAccount& ca)
{
    out << (Account&)ca;
    out << "Transactions Per Day: " << ca.transactionsPerDay << endl;
    out << "Average Annual Balance: " << ca.averageAnnualBalance << endl;
    return out;
}

istream& operator>>(istream& in, CurrentAccount& ca)
{
    in >> (Account&)ca;
    cout << "Enter Transactions Per Day: ";
    in >> ca.transactionsPerDay;
    cout << "Enter Average Annual Balance: ";
    in >> ca.averageAnnualBalance;
    return in;
}
