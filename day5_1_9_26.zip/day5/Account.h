
// create following classes using Inheritance 
// and test whether you can create objects of all classes, 
// and also check whether you can call functions of the classes

// Design a system for XYZ Bank for storing account details, 
// Every account will have type either saving account or current account or demat account
// For every account interest rate and minimum balance need to be stored.
// Interest rate for saving account is 4% and for current account 1%
// Minimum balance for saving account will be 20000 and current account will be 1000
// For each account store account holder details(fname, lname, mobile, email, pin) 
 
// If it’s a saving account, then store chequebooknumber
// If current account then store number of transactions/day, number of transactions will be different for every account based on average annual balance in the account and will keep on changing based on how customer maintains the balance in the account.

// For demat account store share details, for every share store name, number of shares buying price, date of purchase, selling price, date of selling.

// Write a menu driven program
//  1. Add new account
//  2. Display account balance by id
//  3. Close account
//  4. count a type of account. -----> ask user whether count of saving or current account or demat account to display and display aprropriate count 
// 5. Withdraw amount.  ---> allow to withdraw amount only if entered pin is correct and balance is not reduced below minimum balance
// 6. Deposit amount
// 7. Change pin
// 0. Exit


#ifndef ACCOUNT_H // complete meaning of this line is to check whether the ACCOUNT_H macro is already defined or not. If it is not defined, then the code inside the #ifndef block will be included in the compilation. This is a common technique used to prevent multiple inclusions of the same header file, which can lead to compilation errors.
#define ACCOUNT_H // this line defines the ACCOUNT_H macro, indicating that the header file has been included. It is used in conjunction with the #ifndef directive to ensure that the code inside the block is only included once during compilation.

#include <iostream>
#include <cstring> //cstring is a header file in C++ that provides functions for manipulating C-style strings (null-terminated character arrays). It includes functions for string copying, concatenation, comparison, and searching. In this code, it is likely included to perform operations on the character arrays used for storing account holder details such as first name, last name, mobile number, and email address.
using namespace std; // The line "using namespace std;" is used to avoid having to prefix standard library names with "std::". It allows the programmer to use names from the standard namespace (like cout, cin, string, etc.) directly without needing to specify the namespace each time. However, it is generally recommended to use this directive in small programs or within specific scopes to avoid potential name conflicts in larger projects.
// should we use using namespace std; in header file? ans : It is generally not recommended to use "using namespace std;" in header files. This is because it can lead to name conflicts and unexpected behavior when the header file is included in multiple source files. Instead, it is better to use the "std::" prefix for standard library names in header files to avoid potential issues.
class Account
{
    private:
        int accountId;
        char* fname; //fname = first name //why char* is used for fname, lname, mobile, email, accountType instead of string? ans : char* is used for fname, lname, mobile, email, and accountType instead of string to allow for dynamic memory allocation and manual control over memory management. This can be useful in scenarios where the size of the strings may vary or when working with legacy code that uses C-style strings. However, using std::string is generally safer and more convenient as it handles memory management automatically and provides a rich set of functions for string manipulation.
        //why not use string instead of char* for fname, lname, mobile, email, accountType? ans : Using std::string instead of char* for fname, lname, mobile, email, and accountType is generally recommended because std::string provides automatic memory management, built-in functions for string manipulation, and better safety against buffer overflows. It simplifies code and reduces the risk of memory leaks or dangling pointers. However, char* may be used in certain cases for compatibility with legacy code or when fine-grained control over memory allocation is required.
        //how the memory management is done for char* fname, lname, mobile, email, accountType? ans : Memory management for char* fname, lname, mobile, email, and accountType is typically done using dynamic memory allocation functions like new and delete. When an Account object is created or when the setData function is called, memory is allocated for these character arrays based on the length of the input strings. When the Account object is destroyed (in the destructor), the allocated memory is freed using delete[] to prevent memory leaks. It is important to ensure that every allocation has a corresponding deallocation to manage memory properly.
        //example of memory management for char* vs  char[] or string? ans :
        // For char*:
        // char* str = new char[20]; // allocate memory
        // strcpy(str, "Hello"); // copy string
        // delete[] str; // free memory
        // For char[]:
        // char str[20]; // allocate memory on stack
        // strcpy(str, "Hello"); // copy string
        // For std::string:
        // std::string str = "Hello"; // automatic memory management    

        char* lname; //lname = last name
        char* mobile; //mobile = mobile number
        char* email; //email = email address
        int pin; //pin = personal identification number
        double balance; //balance = account balance //why in double? ans : The balance is stored as a double to accommodate decimal values, allowing for precise representation of monetary amounts, including cents. Using a double ensures that calculations involving the balance can handle fractional values accurately, which is essential for financial applications.
        char* accountType; //accountType = type of account 
        double interestRate; //interestRate = interest rate for the account
        double minimumBalance; //minimumBalance = minimum balance required for the account
        
    public:
        Account(int aid = 0, const char* f = "Unknown", const char* l = "Unknown", //why const char* is used for fname, lname, mobile, email, accountType instead of string? ans : const char* is used for fname, lname, mobile, email, and accountType to allow for the use of C-style strings, which are null-terminated character arrays. This can provide more control over memory management and compatibility with legacy code. However, using std::string is generally safer and more convenient as it handles memory management automatically and provides a rich set of functions for string manipulation. The const qualifier indicates that the function will not modify the input strings, ensuring that the original data remains unchanged.
                const char* mob = "0000000000", const char* em = "unknown@email.com", 
                int p = 1234, double bal = 0.0, const char* type = "Saving");//why this constructor is defined with default values for its parameters? ans : This constructor is defined with default values for its parameters to allow for the creation of Account objects without requiring the caller to provide all the details. If no arguments are provided, the constructor will initialize the account with default values, ensuring that the object is in a valid state. This provides flexibility in object creation and simplifies the process of creating accounts when some information may not be available at the time of instantiation.

                //this constructor initializes the account with default values if no parameters are provided. It sets the account ID, first name, last name, mobile number, email address, PIN, balance, and account type. The interest rate and minimum balance are set based on the account type.
        
        Account(const Account &acc);//why copy constructor is defined? ans : The copy constructor is defined to create a new Account object as a copy of an existing Account object. It allows for the proper copying of member variables, including dynamically allocated memory for character arrays. This ensures that when an Account object is copied, the new object has its own separate copies of the data, preventing issues related to shared memory and potential memory leaks. The copy constructor is essential for managing resources correctly in classes that use dynamic memory allocation.
         // this is a copy constructor that creates a new Account object by copying the values from another Account object. It allocates memory for the character arrays and copies the values of the member variables.
        //how this copy constructor is used, and called ? ans : The copy constructor is used when an object of the class is initialized with an existing object of the same class. It is called automatically by the compiler when an object of the class is created as a copy of another object of the same class.
        //syntax for calling copy constructor -> ans : The syntax for calling the copy constructor is as follows:
        // ClassName object2 = object1; // Calls the copy constructor to create object2

        void setData(int aid, const char* f, const char* l, const char* mob, 
                     const char* em, int p, double bal, const char* type); //this function sets the data for an Account object. It takes parameters for account ID, first name, last name, mobile number, email address, PIN, balance, and account type. It allocates memory for the character arrays and copies the values of the member variables. The interest rate and minimum balance are set based on the account type.
        
        int getAccountId() const;
        const char* getFname() const;
        const char* getLname() const;
        const char* getMobile() const;
        const char* getEmail() const;
        int getPin() const;
        double getBalance() const;
        const char* getAccountType() const;
        double getInterestRate() const;
        double getMinimumBalance() const;
        
        virtual void displayData();
        virtual bool withdraw(int enteredPin, double amount);
        virtual void deposit(double amount);
        virtual bool changePin(int oldPin, int newPin);
        //why these 4 functions are declared as virtual? ans : These 4 functions are declared as virtual to allow derived classes to override their behavior. This enables polymorphism, allowing the program to call the appropriate function implementation based on the actual object type at runtime, even when accessed through a base class pointer or reference. This is important for ensuring that the correct behavior is executed for different account types (e.g., saving, current, demat) when performing operations like displaying data, withdrawing, depositing, or changing the PIN.
        //syntax for calling virtual function -> ans : The syntax for calling a virtual function is the same as calling any other member function. However, when using a base class pointer or reference to call a virtual function, the actual function that gets executed is determined at runtime based on the type of the object being pointed to. For example:
        // BaseClass* basePtr = new DerivedClass();
        // basePtr->virtualFunction(); // Calls the overridden function in DerivedClass if it exists
        virtual ~Account(); //this is a virtual destructor that ensures proper cleanup of dynamically allocated memory when an Account object is destroyed. It deallocates the memory for the character arrays.
        //virtual destructor is used to ensure that the derived class's destructor is called when an object of the derived class is deleted through a pointer of the base class type. This is important to avoid memory leaks and ensure proper cleanup of resources.
        //why virtual -> ans : To ensure that the correct  destructor is called for objects of derived classes when they are deleted through pointers to the base class.
        //what if not used the virtual keyword -> ans : If the virtual keyword is not used, deleting a derived class object through a base class pointer will result in undefined behavior. The base class destructor will be called, but the derived class destructor will not be invoked, leading to memory leaks and incomplete cleanup of resources.
        friend ostream& operator<<(ostream& out, const Account& acc);
        // The friend keyword allows the operator<< function to access the private members of the Account class. This enables the function to output the account details directly without needing public getter methods.
        //why friend is used -> ans : The friend keyword is used to grant the operator<< function access to the private members of the Account class. This allows the function to directly access and output the account details without needing public getter methods.
        //what if not used the friend keyword -> ans : If the friend keyword is not used, the operator<< function would not have access to the private members of the Account class. As a result, it would not be able to output the account details directly, and you would need to provide public getter methods to retrieve the data for output.
        // The friend keyword allows the operator>> function to access the private members of the Account class. This enables the function to input account details directly without needing public setter methods.
        // why operator overloading definition are placed outside the class -> ans : Operator overloading definitions are placed outside the class to maintain separation of concerns and improve code readability. It allows the operator functions to be defined independently, making it easier to manage and understand the code. Additionally, placing them outside the class allows for better encapsulation and avoids cluttering the class definition with implementation details.
        //what if used inside the class -> ans : If operator overloading definitions are placed inside the class, it can lead to a more cluttered class definition and may reduce code readability. It can also make it harder to manage and maintain the code, especially if the operator functions are complex. Additionally, placing them inside the class may limit their flexibility and reusability, as they would be tightly coupled with the class implementation.

        friend istream& operator>>(istream& in, Account& acc); // The friend keyword allows the operator>> function to access the private members of the Account class. This enables the function to input account details directly without needing public setter methods.
};


#endif //why #endif is used at the end of the header file? ans : The #endif directive is used at the end of the header file to close the conditional inclusion block that was started with #ifndef. It indicates the end of the code that should be included only if the ACCOUNT_H macro was not previously defined. This ensures that the header file is included only once during compilation, preventing multiple definition errors and improving compilation efficiency.
