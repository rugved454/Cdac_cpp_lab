#ifndef CURRENT_ACCOUNT_H
#define CURRENT_ACCOUNT_H
#include "Account.h"

class CurrentAccount : public Account
{
    private:
        int transactionsPerDay;
        double averageAnnualBalance;
        
    public:
        CurrentAccount(int aid = 0, const char* f = "Unknown", const char* l = "Unknown", 
                      const char* mob = "0000000000", const char* em = "unknown@email.com", 
                      int p = 1234, double bal = 0.0, int tpd = 5, double aab = 100000.0);
        
        CurrentAccount(const CurrentAccount &ca);
        
        void setTransactionsPerDay(int tpd);
        int getTransactionsPerDay() const;
        
        void setAverageAnnualBalance(double aab);
        double getAverageAnnualBalance() const;
        
        virtual void displayData();
        virtual ~CurrentAccount();
        
        friend ostream& operator<<(ostream& out, const CurrentAccount& ca);
        friend istream& operator>>(istream& in, CurrentAccount& ca);
};

#endif
