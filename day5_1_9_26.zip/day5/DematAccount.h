#ifndef DEMAT_ACCOUNT_H
#define DEMAT_ACCOUNT_H
#include "Account.h"

class Share
{
    private:
        char* shareName;
        int numberOfShares;
        double buyingPrice;
        char* dateOfPurchase;
        double sellingPrice;
        char* dateOfSelling;
        
    public:
        Share(const char* name = "Unknown", int num = 0, double bp = 0.0, const char* dop = "00-00-00", double sp = 0.0, const char* dos = "00-00-00");
        Share(const Share &s);
        Share& operator=(const Share &s);
        
        void setShareDetails(const char* name, int num, double bp, const char* dop, double sp, const char* dos);
        
        const char* getShareName() const;
        int getNumberOfShares() const;
        double getBuyingPrice() const;
        const char* getDateOfPurchase() const;
        double getSellingPrice() const;
        const char* getDateOfSelling() const;
        
        void displayShare();
        
        virtual ~Share();
        
        friend ostream& operator<<(ostream& out, const Share& s);
        friend istream& operator>>(istream& in, Share& s);
};

class DematAccount : public Account
{
    private:
        Share* shares;
        int numberOfShares;
        
    public:
        DematAccount(int aid = 0, const char* f = "Unknown", const char* l = "Unknown", 
                    const char* mob = "0000000000", const char* em = "unknown@email.com", 
                    int p = 1234, double bal = 0.0);
        
        DematAccount(const DematAccount &da);
        
        void addShare(const Share &s);
        virtual void displayData();
        void displayAllShares();
        virtual ~DematAccount();
        
        friend ostream& operator<<(ostream& out, const DematAccount& da);
        friend istream& operator>>(istream& in, DematAccount& da);
};

#endif
