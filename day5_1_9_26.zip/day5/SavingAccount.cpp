#include "SavingAccount.h"

SavingAccount::SavingAccount(int aid, const char* f, const char* l, const char* mob, const char* em, int p, double bal, int cbNum)
    : Account(aid, f, l, mob, em, p, bal, "Saving")
{
    chequeBookNumber = cbNum;
}

SavingAccount::SavingAccount(const SavingAccount &sa)
    : Account(sa)
{
    chequeBookNumber = sa.chequeBookNumber;
}

SavingAccount::~SavingAccount()
{
    // Destructor - cleanup handled by base class
}

void SavingAccount::setChequeBookNumber(int cbNum)
{
    chequeBookNumber = cbNum;
}

int SavingAccount::getChequeBookNumber() const
{
    return chequeBookNumber;
}

void SavingAccount::displayData()
{
    Account::displayData();
    cout << "Cheque Book Number: " << chequeBookNumber << endl;
}

ostream& operator<<(ostream& out, const SavingAccount& sa)
{
    out << (Account&)sa;
    out << "Cheque Book Number: " << sa.chequeBookNumber << endl;
    return out;
}

istream& operator>>(istream& in, SavingAccount& sa)
{
    in >> (Account&)sa;
    cout << "Enter Cheque Book Number: ";
    in >> sa.chequeBookNumber;
    return in;
}
