// 2. Design Time Class Using Operator Overloading

// Design and implement a C++ class named `Time` to represent a time duration using two data members:

// * Hours
// * Minutes
// Overload << and >> operator to accept and display Time class object

// The class should maintain a valid time representation where 
// **60 minutes are equal to 1 hour
// **. Whenever an operation causes the minutes to become greater than or equal to 60, the extra minutes should be converted into hours. Similarly, when subtracting time, borrowing should be handled correctly.


// Design default, parametrised and copy constructor


// The class should ensure that the time remains in a valid format after every operation.


// ### 2. Overload the `+` Operator

// Overload the `+` operator to add two `Time` objects.

// The addition should add both the hours and minutes.

// If the total number of minutes is greater than or equal to 60, convert the extra minutes into hours.

// For example:

// * 2 hours 30 minutes + 1 hour 45 minutes = 4 hours 15 minutes
// * 10 hours 50 minutes + 2 hours 30 minutes = 13 hours 20 minutes

// The `+` operation should create and return a new Time object without modifying the original objects.

//  3. Overload the `-` Operator

// Overload the `-` operator to subtract one `Time` object from another.

// If the minutes of the first object are smaller than the minutes of the second object, borrow one hour and convert it into 60 minutes before performing the subtraction.

// For example:

// * 5 hours 30 minutes − 2 hours 45 minutes = 2 hours 45 minutes
// * 10 hours 15 minutes − 2 hours 30 minutes = 7 hours 45 minutes

// The subtraction operation should return a **new `Time` object** and should not modify the original objects.

// ---

// ### 4. Overload the Assignment `=` Operator

// Overload the assignment operator to copy the hours and minutes from one `Time` object to another.

// The assignment operation should support expressions where multiple objects are assigned in a single statement.

// For example:

// * Assign one `Time` object to another.
// * Perform chained assignment involving three or more `Time` objects.
// * Test self-assignment.

// The assignment operator should return the appropriate object so that chained assignment behaves naturally.

// ---

// ### 5. Overload Prefix Increment `++`

// Define the prefix increment operation so that it **adds one minute** to the current `Time` object.

// For example:

// * Before increment: 10 hours 59 minutes
// * After prefix increment: 11 hours 00 minutes

// The operation should modify the existing object and return the updated object according to normal C++ operator conventions.

// ---

// ### 6. Overload Postfix Increment `++`

// Define the postfix increment operation so that it also adds one minute to the `Time` object.

// However, the postfix operation must preserve the original value before incrementing.

// For example:

// * Original time: 10 hours 59 minutes
// * Store the result of the postfix operation in another object.
// * The new object should contain 10 hours 59 minutes.
// * The original object should become 11 hours 00 minutes.

// The postfix form should return the **old state/value** of the object. The postfix operator is distinguished from the prefix version using a dummy integer parameter.

// ---

// ### 7. Overload Prefix Decrement `--`

// Define the prefix decrement operation so that it **subtracts one minute** from the current `Time` object.

// For example:

// * Before decrement: 11 hours 00 minutes
// * After decrement: 10 hours 59 minutes

// If the number of minutes becomes negative, borrow one hour and adjust the minutes accordingly.

// The operation should modify the existing object and return the updated object.

// ---

// ### 8. Overload Postfix Decrement `--`

// Define the postfix decrement operation so that it subtracts one minute but returns the value of the object **before decrementing**.

// For example:

// * Original time: 11 hours 00 minutes
// * Store the result of the postfix operation in another object.
// * The new object should contain 11 hours 00 minutes.
// * The original object should become 10 hours 59 minutes.

// The postfix operation should preserve and return the old value while modifying the original object.

// ---

// ## Testing Requirements
// Write a TestTime class add main method  to test following operations:
// 1. Create multiple `Time` objects. //practice calling all 3 types of constructor
// 2. Initialize them with different hours and minutes.
// 3. Add two `Time` objects.
// 4. Subtract one `Time` object from another.
// 5. Assign one `Time` object to another.
// 6. Perform chained assignment.
// 7. Perform prefix increment.
// 8. Perform postfix increment and verify the difference between the old and new values.
// 9. Perform prefix decrement.
// 10. Perform postfix decrement and verify the difference between the old and new values.
// 11. Display the result after every operation.



#include <iostream>
using namespace std;

class Time{
    private:
        int hours;
        int minutes;
    public:
        Time(){
            hours = 0;
            minutes = 0;
        }
        
        Time(int hrs,int mins){
            hours = hrs;
            minutes = mins;
            if(minutes >= 60){
                hours += minutes / 60;
                minutes = minutes % 60;
            }
        }
        Time (const Time &t){
            hours = t.hours;
            minutes = t.minutes;
        }

        void displayTime(){
            cout << hours << " hours " << minutes << " minutes" << endl;
        }
        Time operator+(const Time &t){
            Time temp;
            temp.hours = hours + t.hours;
            temp.minutes = minutes + t.minutes;
            if(temp.minutes >= 60){
                temp.hours += temp.minutes / 60;
                temp.minutes = temp.minutes % 60;
            }
            return temp;
        }
        Time operator-(const Time &t){
            Time temp;
            temp.hours = hours - t.hours;
            temp.minutes = minutes - t.minutes;
            if(temp.minutes < 0){
                temp.hours--;
                temp.minutes += 60;
            }
            return temp;
        }
        Time& operator=(const Time &t){
            if(this != &t){
                hours = t.hours;
                minutes = t.minutes;
            }
            return *this;
        }
        Time& operator++(){
            minutes++;
            if(minutes >= 60){
                hours++;
                minutes = 0;
            }
            return *this;
        }
        Time operator++(int){
            Time temp = *this;
            minutes++;
            if(minutes >= 60){
                hours++;
                minutes = 0;
            }
            return temp;
        }
        Time& operator--(){
            minutes--;
            if(minutes < 0){
                hours--;
                minutes = 59;
            }
            return *this;
        }
        Time operator--(int){
            Time temp = *this;
            minutes--;
            if(minutes < 0){
                hours--;
                minutes = 59;
            }
            return temp;
        }
        
        friend ostream& operator<<(ostream &out, const Time &t);

        friend istream& operator>>(istream &in, Time &t);



};
ostream& operator<<(ostream &out, const Time &t){
    out << t.hours << " hours " << t.minutes << " minutes";
    return out;
}
istream& operator>>(istream &in, Time &t){
    cout << "Enter hours: ";
    in >> t.hours;
    cout << "Enter minutes: ";       
    in >> t.minutes;
    return in;
}
int main(){
    Time t1(2, 30);
    Time t2(1, 45);
    Time t3 = t1 + t2;
    cout << "t1: " << t1 << endl;
    cout << "t2: " << t2 << endl;
    cout << "t3 (t1 + t2): " << t3 << endl;

    Time t4(10, 20);
    Time t5(2, 70);
    Time t6 = t4 + t5;
    cout << "t4: " << t4 << endl;
    cout << "t5: " << t5 << endl;
    cout << "t6 (t4 + t5): " << t6 << endl;

    //copy constructor
    Time t7(t6);
    cout << "t7 (copy of t6): " << t7 << endl;

    Time t8;
    t8 = t7;
    cout << "t8 (assigned from t7): " << t8 << endl;

    Time t9;
    t9 = t8 = t7;
    cout << "t9 (chained assignment from t8 and t7): " << t9 << endl;
    Time t10(5, 30);
    Time t11(2, 45);
    Time t12 = t10 - t11;
    cout << "t10: " << t10 << endl;
    cout << "t11: " << t11 << endl;
    cout << "t12 (t10 - t11): " << t12 << endl;
    Time t13(10, 15);
    t13++;
    cout << "t13 after postfix increment: " << t13 << endl;
    ++t13;
    cout << "t13 after prefix increment: " << t13 << endl;
    Time t14(11, 0);
    t14--;
    cout << "t14 after postfix decrement: " << t14 << endl;
    --t14;
    cout << "t14 after prefix decrement: " << t14 << endl;  


    return 0;
}