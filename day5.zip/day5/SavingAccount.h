#ifndef SAVING_ACCOUNT_H
#define SAVING_ACCOUNT_H
#include "Account.h"

class SavingAccount : public Account
{
    private:
        int chequeBookNumber;
        
    public:
        SavingAccount(int aid = 0, const char* f = "Unknown", const char* l = "Unknown", 
                     const char* mob = "0000000000", const char* em = "unknown@email.com", 
                     int p = 1234, double bal = 0.0, int cbNum = 0);
        
        SavingAccount(const SavingAccount &sa);
        
        void setChequeBookNumber(int cbNum);
        int getChequeBookNumber() const;
        
        void displayData();
        
        friend ostream& operator<<(ostream& out, const SavingAccount& sa);
        friend istream& operator>>(istream& in, SavingAccount& sa);
};

#endif
