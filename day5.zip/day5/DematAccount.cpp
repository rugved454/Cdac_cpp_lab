#include "DematAccount.h"

Share::Share(const char* name, int num, double bp, const char* dop, double sp, const char* dos)
{
    shareName = new char[strlen(name) + 1];
    strcpy(shareName, name);
    numberOfShares = num;
    buyingPrice = bp;
    dateOfPurchase = new char[strlen(dop) + 1];
    strcpy(dateOfPurchase, dop);
    sellingPrice = sp;
    dateOfSelling = new char[strlen(dos) + 1];
    strcpy(dateOfSelling, dos);
}

Share::Share(const Share &s)
{
    shareName = new char[strlen(s.shareName) + 1];
    strcpy(shareName, s.shareName);
    numberOfShares = s.numberOfShares;
    buyingPrice = s.buyingPrice;
    dateOfPurchase = new char[strlen(s.dateOfPurchase) + 1];
    strcpy(dateOfPurchase, s.dateOfPurchase);
    sellingPrice = s.sellingPrice;
    dateOfSelling = new char[strlen(s.dateOfSelling) + 1];
    strcpy(dateOfSelling, s.dateOfSelling);
}

void Share::setShareDetails(const char* name, int num, double bp, const char* dop, double sp, const char* dos)
{
    shareName = new char[strlen(name) + 1];
    strcpy(shareName, name);
    numberOfShares = num;
    buyingPrice = bp;
    dateOfPurchase = new char[strlen(dop) + 1];
    strcpy(dateOfPurchase, dop);
    sellingPrice = sp;
    dateOfSelling = new char[strlen(dos) + 1];
    strcpy(dateOfSelling, dos);
}

const char* Share::getShareName() const
{
    return shareName;
}

int Share::getNumberOfShares() const
{
    return numberOfShares;
}

double Share::getBuyingPrice() const
{
    return buyingPrice;
}

const char* Share::getDateOfPurchase() const
{
    return dateOfPurchase;
}

double Share::getSellingPrice() const
{
    return sellingPrice;
}

const char* Share::getDateOfSelling() const
{
    return dateOfSelling;
}

void Share::displayShare()
{
    cout << "Share Name: " << shareName << endl;
    cout << "Number of Shares: " << numberOfShares << endl;
    cout << "Buying Price: " << buyingPrice << endl;
    cout << "Date of Purchase: " << dateOfPurchase << endl;
    cout << "Selling Price: " << sellingPrice << endl;
    cout << "Date of Selling: " << dateOfSelling << endl;
}

ostream& operator<<(ostream& out, const Share& s)
{
    out << "Share Name: " << s.shareName << endl;
    out << "Number of Shares: " << s.numberOfShares << endl;
    out << "Buying Price: " << s.buyingPrice << endl;
    out << "Date of Purchase: " << s.dateOfPurchase << endl;
    out << "Selling Price: " << s.sellingPrice << endl;
    out << "Date of Selling: " << s.dateOfSelling << endl;
    return out;
}

istream& operator>>(istream& in, Share& s)
{
    char name[50], dop[20], dos[20];
    
    cout << "Enter Share Name: ";
    in >> name;
    s.shareName = new char[strlen(name) + 1];
    strcpy(s.shareName, name);
    
    cout << "Enter Number of Shares: ";
    in >> s.numberOfShares;
    
    cout << "Enter Buying Price: ";
    in >> s.buyingPrice;
    
    cout << "Enter Date of Purchase (DD-MM-YY): ";
    in >> dop;
    s.dateOfPurchase = new char[strlen(dop) + 1];
    strcpy(s.dateOfPurchase, dop);
    
    cout << "Enter Selling Price: ";
    in >> s.sellingPrice;
    
    cout << "Enter Date of Selling (DD-MM-YY): ";
    in >> dos;
    s.dateOfSelling = new char[strlen(dos) + 1];
    strcpy(s.dateOfSelling, dos);
    
    return in;
}

DematAccount::DematAccount(int aid, const char* f, const char* l, const char* mob, const char* em, int p, double bal)
    : Account(aid, f, l, mob, em, p, bal, "Demat")
{
    shares = nullptr;
    numberOfShares = 0;
}

DematAccount::DematAccount(const DematAccount &da)
    : Account(da)
{
    numberOfShares = da.numberOfShares;
    if(numberOfShares > 0)
    {
        shares = new Share[numberOfShares];
        for(int i = 0; i < numberOfShares; i++)
        {
            shares[i] = da.shares[i];
        }
    }
    else
    {
        shares = nullptr;
    }
}

void DematAccount::addShare(const Share &s)
{
    Share* temp = new Share[numberOfShares + 1];
    if(shares != nullptr)
    {
        for(int i = 0; i < numberOfShares; i++)
        {
            temp[i] = shares[i];
        }
        delete[] shares;
    }
    temp[numberOfShares] = s;
    shares = temp;
    numberOfShares++;
}

void DematAccount::displayData()
{
    Account::displayData();
    cout << "Number of Shares: " << numberOfShares << endl;
}

void DematAccount::displayAllShares()
{
    cout << "\n==== All Shares ====" << endl;
    for(int i = 0; i < numberOfShares; i++)
    {
        cout << "\nShare " << (i+1) << ":" << endl;
        shares[i].displayShare();
    }
}

ostream& operator<<(ostream& out, const DematAccount& da)
{
    out << (Account&)da;
    out << "Number of Shares: " << da.numberOfShares << endl;
    for(int i = 0; i < da.numberOfShares; i++)
    {
        out << "\nShare " << (i+1) << ":" << endl;
        out << da.shares[i];
    }
    return out;
}

istream& operator>>(istream& in, DematAccount& da)
{
    in >> (Account&)da;
    int numShares;
    cout << "Enter Number of Shares: ";
    in >> numShares;
    
    for(int i = 0; i < numShares; i++)
    {
        Share s;
        in >> s;
        da.addShare(s);
    }
    return in;
}
