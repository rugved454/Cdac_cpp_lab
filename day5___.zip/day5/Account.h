
// create following classes using Inheritance 
// and test whether you can create objects of all classes, 
// and also check whether you can call functions of the classes

// Design a system for XYZ Bank for storing account details, 
// Every account will have type either saving account or current account or demat account
// For every account interest rate and minimum balance need to be stored.
// Interest rate for saving account is 4% and for current account 1%
// Minimum balance for saving account will be 20000 and current account will be 1000
// For each account store account holder details(fname, lname, mobile, email, pin) 
 
// If it’s a saving account, then store chequebooknumber
// If current account then store number of transactions/day, number of transactions will be different for every account based on average annual balance in the account and will keep on changing based on how customer maintains the balance in the account.

// For demat account store share details, for every share store name, number of shares buying price, date of purchase, selling price, date of selling.

// Write a menu driven program
//  1. Add new account
//  2. Display account balance by id
//  3. Close account
//  4. count a type of account. -----> ask user whether count of saving or current account or demat account to display and display aprropriate count 
// 5. Withdraw amount.  ---> allow to withdraw amount only if entered pin is correct and balance is not reduced below minimum balance
// 6. Deposit amount
// 7. Change pin
// 0. Exit


#ifndef ACCOUNT_H
#define ACCOUNT_H
#include <iostream>
#include <cstring>
using namespace std;

class Account
{
    private:
        int accountId;
        char* fname; //fname = first name
        char* lname; //lname = last name
        char* mobile; //mobile = mobile number
        char* email; //email = email address
        int pin; //pin = personal identification number
        double balance; //balance = account balance
        char* accountType; //accountType = type of account
        double interestRate; //interestRate = interest rate for the account
        double minimumBalance; //minimumBalance = minimum balance required for the account
        
    public:
        Account(int aid = 0, const char* f = "Unknown", const char* l = "Unknown", 
                const char* mob = "0000000000", const char* em = "unknown@email.com", 
                int p = 1234, double bal = 0.0, const char* type = "Saving");

                //this constructor initializes the account with default values if no parameters are provided. It sets the account ID, first name, last name, mobile number, email address, PIN, balance, and account type. The interest rate and minimum balance are set based on the account type.
        
        Account(const Account &acc); // this is a copy constructor that creates a new Account object by copying the values from another Account object. It allocates memory for the character arrays and copies the values of the member variables.
        
        void setData(int aid, const char* f, const char* l, const char* mob, 
                     const char* em, int p, double bal, const char* type); //this function sets the data for an Account object. It takes parameters for account ID, first name, last name, mobile number, email address, PIN, balance, and account type. It allocates memory for the character arrays and copies the values of the member variables. The interest rate and minimum balance are set based on the account type.
        
        int getAccountId() const;
        const char* getFname() const;
        const char* getLname() const;
        const char* getMobile() const;
        const char* getEmail() const;
        int getPin() const;
        double getBalance() const;
        const char* getAccountType() const;
        double getInterestRate() const;
        double getMinimumBalance() const;
        
        virtual void displayData();
        virtual bool withdraw(int enteredPin, double amount);
        virtual void deposit(double amount);
        virtual bool changePin(int oldPin, int newPin);
        
        virtual ~Account(); //this is a virtual destructor that ensures proper cleanup of dynamically allocated memory when an Account object is destroyed. It deallocates the memory for the character arrays.
        //virtual destructor is used to ensure that the derived class's destructor is called when an object of the derived class is deleted through a pointer of the base class type. This is important to avoid memory leaks and ensure proper cleanup of resources.
        //why virtual -> ans : To ensure that the correct destructor is called for objects of derived classes when they are deleted through pointers to the base class.
        //what if not used the virtual keyword -> ans : If the virtual keyword is not used, deleting a derived class object through a base class pointer will result in undefined behavior. The base class destructor will be called, but the derived class destructor will not be invoked, leading to memory leaks and incomplete cleanup of resources.
        friend ostream& operator<<(ostream& out, const Account& acc);
        // The friend keyword allows the operator<< function to access the private members of the Account class. This enables the function to output the account details directly without needing public getter methods.
        //why friend is used -> ans : The friend keyword is used to grant the operator<< function access to the private members of the Account class. This allows the function to directly access and output the account details without needing public getter methods.
        //what if not used the friend keyword -> ans : If the friend keyword is not used, the operator<< function would not have access to the private members of the Account class. As a result, it would not be able to output the account details directly, and you would need to provide public getter methods to retrieve the data for output.
        // The friend keyword allows the operator>> function to access the private members of the Account class. This enables the function to input account details directly without needing public setter methods.
        // why operator overloading definition are placed outside the class -> ans : Operator overloading definitions are placed outside the class to maintain separation of concerns and improve code readability. It allows the operator functions to be defined independently, making it easier to manage and understand the code. Additionally, placing them outside the class allows for better encapsulation and avoids cluttering the class definition with implementation details.

        friend istream& operator>>(istream& in, Account& acc); // The friend keyword allows the operator>> function to access the private members of the Account class. This enables the function to input account details directly without needing public setter methods.
};



#endif
