#include "Account.h"

Account::Account(int aid, const char* f, const char* l, const char* mob, const char* em, int p, double bal, const char* type)
{
    accountId = aid; //accountId = account ID
    fname = new char[strlen(f) + 1]; //why is this necessary -> ans : This is necessary to allocate memory for the first name string. It ensures that there is enough space to store the characters of the first name, including the null terminator.
    
    strcpy(fname, f);
    lname = new char[strlen(l) + 1];
    strcpy(lname, l);
    mobile = new char[strlen(mob) + 1];
    strcpy(mobile, mob);
    email = new char[strlen(em) + 1];
    strcpy(email, em);
    pin = p;
    balance = bal;
    accountType = new char[strlen(type) + 1];
    strcpy(accountType, type);
    
    if(strcmp(type, "Saving") == 0)
    {
        interestRate = 4.0;
        minimumBalance = 20000.0;
    }
    else if(strcmp(type, "Current") == 0)
    {
        interestRate = 1.0;
        minimumBalance = 1000.0;
    }
    else if(strcmp(type, "Demat") == 0)
    {
        interestRate = 0.0;
        minimumBalance = 0.0;
    }
}

Account::~Account()
{
    delete[] fname;
    delete[] lname;
    delete[] mobile;
    delete[] email;
    delete[] accountType;
}

Account::Account(const Account &acc)
{
    accountId = acc.accountId;
    fname = new char[strlen(acc.fname) + 1];
    strcpy(fname, acc.fname);
    lname = new char[strlen(acc.lname) + 1];
    strcpy(lname, acc.lname);
    mobile = new char[strlen(acc.mobile) + 1];
    strcpy(mobile, acc.mobile);
    email = new char[strlen(acc.email) + 1];
    strcpy(email, acc.email);
    pin = acc.pin;
    balance = acc.balance;
    accountType = new char[strlen(acc.accountType) + 1];
    strcpy(accountType, acc.accountType);
    interestRate = acc.interestRate;
    minimumBalance = acc.minimumBalance;
}

void Account::setData(int aid, const char* f, const char* l, const char* mob, const char* em, int p, double bal, const char* type)
{
    accountId = aid;
    fname = new char[strlen(f) + 1];
    strcpy(fname, f);
    lname = new char[strlen(l) + 1];
    strcpy(lname, l);
    mobile = new char[strlen(mob) + 1];
    strcpy(mobile, mob);
    email = new char[strlen(em) + 1];
    strcpy(email, em);
    pin = p;
    balance = bal;
    accountType = new char[strlen(type) + 1];
    strcpy(accountType, type);
    
    if(strcmp(type, "Saving") == 0)
    {
        interestRate = 4.0;
        minimumBalance = 20000.0;
    }
    else if(strcmp(type, "Current") == 0)
    {
        interestRate = 1.0;
        minimumBalance = 1000.0;
    }
    else if(strcmp(type, "Demat") == 0)
    {
        interestRate = 0.0;
        minimumBalance = 0.0;
    }
}

int Account::getAccountId() const
{
    return accountId;
}

const char* Account::getFname() const
{
    return fname;
}

const char* Account::getLname() const
{
    return lname;
}

const char* Account::getMobile() const
{
    return mobile;
}

const char* Account::getEmail() const
{
    return email;
}

int Account::getPin() const
{
    return pin;
}

double Account::getBalance() const
{
    return balance;
}

const char* Account::getAccountType() const
{
    return accountType;
}

double Account::getInterestRate() const
{
    return interestRate;
}

double Account::getMinimumBalance() const
{
    return minimumBalance;
}

void Account::displayData()
{
    cout << "Account ID: " << accountId << endl;
    cout << "Name: " << fname << " " << lname << endl;
    cout << "Mobile: " << mobile << endl;
    cout << "Email: " << email << endl;
    cout << "PIN: " << pin << endl;
    cout << "Balance: " << balance << endl;
    cout << "Account Type: " << accountType << endl;
    cout << "Interest Rate: " << interestRate << "%" << endl;
    cout << "Minimum Balance: " << minimumBalance << endl;
}

bool Account::withdraw(int enteredPin, double amount)
{
    if(enteredPin != pin)
    {
        cout << "Invalid PIN!" << endl;
        return false;
    }
    if((balance - amount) < minimumBalance)
    {
        cout << "Cannot withdraw. Minimum balance requirement not met!" << endl;
        return false;
    }
    balance -= amount;
    cout << "Withdrawal successful. New balance: " << balance << endl;
    return true;
}

void Account::deposit(double amount)
{
    balance += amount;
    cout << "Deposit successful. New balance: " << balance << endl;
}

bool Account::changePin(int oldPin, int newPin)
{
    if(oldPin != pin)
    {
        cout << "Old PIN incorrect!" << endl;
        return false;
    }
    pin = newPin;
    cout << "PIN changed successfully!" << endl;
    return true;
}

ostream& operator<<(ostream& out, const Account& acc)
{
    out << "Account ID: " << acc.accountId << endl;
    out << "Name: " << acc.fname << " " << acc.lname << endl;
    out << "Mobile: " << acc.mobile << endl;
    out << "Email: " << acc.email << endl;
    out << "PIN: " << acc.pin << endl;
    out << "Balance: " << acc.balance << endl;
    out << "Account Type: " << acc.accountType << endl;
    out << "Interest Rate: " << acc.interestRate << "%" << endl;
    out << "Minimum Balance: " << acc.minimumBalance << endl;
    return out;
}

istream& operator>>(istream& in, Account& acc)
{
    char f[50], l[50], mob[15], em[50], type[20];
    
    cout << "Enter Account ID: ";
    in >> acc.accountId;
    cout << "Enter First Name: ";
    in >> f;
    acc.fname = new char[strlen(f) + 1];
    strcpy(acc.fname, f);
    
    cout << "Enter Last Name: ";
    in >> l;
    acc.lname = new char[strlen(l) + 1];
    strcpy(acc.lname, l);
    
    cout << "Enter Mobile: ";
    in >> mob;
    acc.mobile = new char[strlen(mob) + 1];
    strcpy(acc.mobile, mob);
    
    cout << "Enter Email: ";
    in >> em;
    acc.email = new char[strlen(em) + 1];
    strcpy(acc.email, em);
    
    cout << "Enter PIN: ";
    in >> acc.pin;
    
    cout << "Enter Balance: ";
    in >> acc.balance;
    
    cout << "Enter Account Type (Saving/Current/Demat): ";
    in >> type;
    acc.accountType = new char[strlen(type) + 1];
    strcpy(acc.accountType, type);
    
    if(strcmp(type, "Saving") == 0)
    {
        acc.interestRate = 4.0;
        acc.minimumBalance = 20000.0;
    }
    else if(strcmp(type, "Current") == 0)
    {
        acc.interestRate = 1.0;
        acc.minimumBalance = 1000.0;
    }
    else if(strcmp(type, "Demat") == 0)
    {
        acc.interestRate = 0.0;
        acc.minimumBalance = 0.0;
    }
    
    return in;
}
