#include "Account.h"
#include "SavingAccount.h"
#include "CurrentAccount.h"
#include "DematAccount.h"
#include <vector>

class Bank
{
    private:
        vector<Account*> accounts;
        int accountCount;
        
    public:
        Bank()
        {
            accountCount = 0;
        }
        
        void addAccount(Account* acc)
        {
            accounts.push_back(acc);
            accountCount++;
            cout << "\nAccount added successfully!" << endl;
        }
        
        void displayAccountById(int id)
        {
            bool found = false;
            for(int i = 0; i < accountCount; i++)
            {
                if(accounts[i]->getAccountId() == id)
                {
                    cout << "\n==== Account Details ====" << endl;
                    cout << *accounts[i];
                    found = true;
                    break;
                }
            }
            if(!found)
            {
                cout << "\nAccount ID not found!" << endl;
            }
        }
        
        void closeAccount(int id)
        {
            bool found = false;
            for(int i = 0; i < accountCount; i++)
            {
                if(accounts[i]->getAccountId() == id)
                {
                    cout << "\nClosing Account ID: " << id << endl;
                    cout << "Account Details:" << endl;
                    cout << *accounts[i];
                    accounts.erase(accounts.begin() + i);
                    accountCount--;
                    cout << "Account closed successfully!" << endl;
                    found = true;
                    break;
                }
            }
            if(!found)
            {
                cout << "\nAccount ID not found!" << endl;
            }
        }
        
        void countAccountType()
        {
            int savingCount = 0, currentCount = 0, dematCount = 0;
            
            for(int i = 0; i < accountCount; i++)
            {
                if(strcmp(accounts[i]->getAccountType(), "Saving") == 0)
                    savingCount++;
                else if(strcmp(accounts[i]->getAccountType(), "Current") == 0)
                    currentCount++;
                else if(strcmp(accounts[i]->getAccountType(), "Demat") == 0)
                    dematCount++;
            }
            
            cout << "\n==== Account Count by Type ====" << endl;
            cout << "Saving Accounts: " << savingCount << endl;
            cout << "Current Accounts: " << currentCount << endl;
            cout << "Demat Accounts: " << dematCount << endl;
            cout << "Total Accounts: " << accountCount << endl;
        }
        
        void withdrawAmount()
        {
            int id, pin;
            double amount;
            
            cout << "\nEnter Account ID: ";
            cin >> id;
            cout << "Enter PIN: ";
            cin >> pin;
            cout << "Enter Amount to Withdraw: ";
            cin >> amount;
            
            bool found = false;
            for(int i = 0; i < accountCount; i++)
            {
                if(accounts[i]->getAccountId() == id)
                {
                    accounts[i]->withdraw(pin, amount);
                    found = true;
                    break;
                }
            }
            if(!found)
            {
                cout << "\nAccount ID not found!" << endl;
            }
        }
        
        void depositAmount()
        {
            int id;
            double amount;
            
            cout << "\nEnter Account ID: ";
            cin >> id;
            cout << "Enter Amount to Deposit: ";
            cin >> amount;
            
            bool found = false;
            for(int i = 0; i < accountCount; i++)
            {
                if(accounts[i]->getAccountId() == id)
                {
                    accounts[i]->deposit(amount);
                    found = true;
                    break;
                }
            }
            if(!found)
            {
                cout << "\nAccount ID not found!" << endl;
            }
        }
        
        void changePin()
        {
            int id, oldPin, newPin;
            
            cout << "\nEnter Account ID: ";
            cin >> id;
            cout << "Enter Old PIN: ";
            cin >> oldPin;
            cout << "Enter New PIN: ";
            cin >> newPin;
            
            bool found = false;
            for(int i = 0; i < accountCount; i++)
            {
                if(accounts[i]->getAccountId() == id)
                {
                    accounts[i]->changePin(oldPin, newPin);
                    found = true;
                    break;
                }
            }
            if(!found)
            {
                cout << "\nAccount ID not found!" << endl;
            }
        }
        
        void displayAllAccounts()
        {
            if(accountCount == 0)
            {
                cout << "\nNo accounts available!" << endl;
                return;
            }
            
            cout << "\n==== All Accounts ====" << endl;
            for(int i = 0; i < accountCount; i++)
            {
                cout << "\nAccount " << (i+1) << ":" << endl;
                cout << *accounts[i];
                cout << "------------------------" << endl;
            }
        }
        
        void displayMenu()
        {
            cout << "\n====== XYZ BANK MENU ======" << endl;
            cout << "1. Add new account" << endl;
            cout << "2. Display account balance by ID" << endl;
            cout << "3. Close account" << endl;
            cout << "4. Count accounts by type" << endl;
            cout << "5. Withdraw amount" << endl;
            cout << "6. Deposit amount" << endl;
            cout << "7. Change PIN" << endl;
            cout << "8. Display all accounts" << endl;
            cout << "0. Exit" << endl;
            cout << "===========================" << endl;
        }
};

int main()
{
    Bank bank;
    int choice;
    
    // Test 1: Create objects of all 3 types with different constructors
    cout << "\n========== TESTING OBJECT CREATION ==========" << endl;
    
    // Using parametrized constructor
    Account a1(101, "Rajesh", "Kumar", "9876543210", "rajesh@email.com", 1234, 50000.0, "Saving");
    cout << "\nTest 1: Account with parametrized constructor:" << endl;
    cout << a1;
    
    // Using default constructor
    Account a2;
    cout << "\nTest 2: Account with default constructor:" << endl;
    cout << a2;
    
    // Using copy constructor
    Account a3(a1);
    cout << "\nTest 3: Account with copy constructor (copy of a1):" << endl;
    cout << a3;
    
    // Testing SavingAccount
    SavingAccount sa1(201, "Priya", "Singh", "9876543211", "priya@email.com", 5678, 75000.0, 1001);
    cout << "\nTest 4: SavingAccount with parametrized constructor:" << endl;
    cout << sa1;
    
    // Testing CurrentAccount
    CurrentAccount ca1(301, "Amit", "Patel", "9876543212", "amit@email.com", 9012, 100000.0, 10, 500000.0);
    cout << "\nTest 5: CurrentAccount with parametrized constructor:" << endl;
    cout << ca1;
    
    // Testing DematAccount
    DematAccount da1(401, "Sneha", "Gupta", "9876543213", "sneha@email.com", 3456, 200000.0);
    cout << "\nTest 6: DematAccount with parametrized constructor:" << endl;
    cout << da1;
    
    cout << "\n=========== TESTING COPY CONSTRUCTORS ===========" << endl;
    
    SavingAccount sa2(sa1);
    cout << "\nTest 7: SavingAccount copy constructor:" << endl;
    cout << sa2;
    
    CurrentAccount ca2(ca1);
    cout << "\nTest 8: CurrentAccount copy constructor:" << endl;
    cout << ca2;
    
    DematAccount da2(da1);
    cout << "\nTest 9: DematAccount copy constructor:" << endl;
    cout << da2;
    
    // Add accounts to bank
    bank.addAccount(&a1);
    bank.addAccount(&sa1);
    bank.addAccount(&ca1);
    bank.addAccount(&da1);
    
    cout << "\n========== MENU-DRIVEN PROGRAM ==========" << endl;
    
    while(true)
    {
        bank.displayMenu();
        cout << "Enter your choice: ";
        cin >> choice;
        
        switch(choice)
        {
            case 1:
            {
                int aid, pin;
                double bal;
                char fname[50], lname[50], mobile[15], email[50], accountType[20];
                
                cout << "\n------ Add New Account ------" << endl;
                cout << "Select Account Type:" << endl;
                cout << "1. Saving Account" << endl;
                cout << "2. Current Account" << endl;
                cout << "3. Demat Account" << endl;
                cout << "Enter choice: ";
                int typeChoice;
                cin >> typeChoice;
                
                cout << "Enter Account ID: ";
                cin >> aid;
                cout << "Enter First Name: ";
                cin >> fname;
                cout << "Enter Last Name: ";
                cin >> lname;
                cout << "Enter Mobile: ";
                cin >> mobile;
                cout << "Enter Email: ";
                cin >> email;
                cout << "Enter PIN: ";
                cin >> pin;
                cout << "Enter Balance: ";
                cin >> bal;
                
                if(typeChoice == 1)
                {
                    int cbNum;
                    cout << "Enter Cheque Book Number: ";
                    cin >> cbNum;
                    SavingAccount* sa = new SavingAccount(aid, fname, lname, mobile, email, pin, bal, cbNum);
                    bank.addAccount(sa);
                }
                else if(typeChoice == 2)
                {
                    int tpd;
                    double aab;
                    cout << "Enter Transactions Per Day: ";
                    cin >> tpd;
                    cout << "Enter Average Annual Balance: ";
                    cin >> aab;
                    CurrentAccount* ca = new CurrentAccount(aid, fname, lname, mobile, email, pin, bal, tpd, aab);
                    bank.addAccount(ca);
                }
                else if(typeChoice == 3)
                {
                    DematAccount* da = new DematAccount(aid, fname, lname, mobile, email, pin, bal);
                    bank.addAccount(da);
                }
                else
                {
                    cout << "Invalid choice!" << endl;
                }
                break;
            }
            
            case 2:
            {
                int id;
                cout << "\nEnter Account ID: ";
                cin >> id;
                bank.displayAccountById(id);
                break;
            }
            
            case 3:
            {
                int id;
                cout << "\nEnter Account ID to Close: ";
                cin >> id;
                bank.closeAccount(id);
                break;
            }
            
            case 4:
            {
                bank.countAccountType();
                break;
            }
            
            case 5:
            {
                bank.withdrawAmount();
                break;
            }
            
            case 6:
            {
                bank.depositAmount();
                break;
            }
            
            case 7:
            {
                bank.changePin();
                break;
            }
            
            case 8:
            {
                bank.displayAllAccounts();
                break;
            }
            
            case 0:
            {
                cout << "\nThank you for using XYZ Bank. Goodbye!" << endl;
                return 0;
            }
            
            default:
            {
                cout << "\nInvalid choice! Please try again." << endl;
            }
        }
    }
    
    return 0;
}
